# node-evowebservices-sst
The EvoStream web service for the Azure Security/Survailance Template
